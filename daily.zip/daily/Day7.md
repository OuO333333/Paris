# 🗓️ Day 7 – 10/27（日）聖米歇爾山 → 雷恩 → 巴黎

| 行程 | 時間 | 交通 | 停留時間 | PMP / 門票 | 備註 |
|------|------|------|-----------|-------------|------|
| 早餐 | 07:30–08:00 | — | 約 30 分鐘 | — | Hôtel Vert 餐廳用餐，簡單自助早餐 |
| 上午自由活動 / 退房 | 08:00–10:30 | 🚶‍♀️步行 | 約 2.5 小時 | — | 可在 La Caserne 區與堤道散步、拍照或購物（建議 10:30 退房） |
| 前往巴士站 | 10:30–11:00 | 🚶‍♀️步行（約 5 分鐘） | 約 30 分鐘 | — | 建議提早到 Keolis 巴士站等候（就在 La Caserne 接駁區旁） |
| 前往雷恩（Rennes） | 11:35–12:50 | 🚌 Keolis 巴士（Mont-Saint-Michel → Rennes 車站） | 約 1 小時 15 分 | ✅ 含於聯票或單買 €15 左右 | 沿途欣賞布列塔尼鄉間風光 |
| 午餐 | 12:50–13:30 | 🍴 Rennes 車站附近餐廳 | 約 40 分鐘 | — | 可選 Café de Rennes 或 Paul 麵包坊簡餐 |
| 搭乘 TGV 返回巴黎 | 13:30–15:02 | 🚆 OUIGO Grande Vitesse 7612 （Rennes → Paris Montparnasse） | 約 1 小時 32 分 | ✅ PMP 約 €32 | 建議提早 20 分鐘上車 |
| 抵達巴黎 Montparnasse | 15:02 | — | — | — | 可接續安排輕鬆下午行程（如 Montparnasse Tower 或 Le Bon Marché 百貨） |
| 下午行程建議 | 15:30–18:30 | 🚇 地鐵 / 🚶‍♀️步行 | 約 3 小時 | — | ✦ Montparnasse Tower 觀景台（登塔賞景）<br>✦ Le Bon Marché 百貨與 La Grande Épicerie 美食超市<br>✦ 盧森堡公園 (Luxembourg Garden) 漫步 |
| 晚餐 | 18:30–20:00 | 🍴 巴黎餐廳 | 約 1.5 小時 | — | 可選 Bouillon Chartier Montparnasse 或 附近小酒館 |
| 返回住宿 | 20:00 之後 | 🚇 地鐵 / 🚶‍♀️ | — | — | 回飯店休息，準備隔日行程 |

---

✅ **小提醒：**
- Keolis 巴士的 Mont-Saint-Michel 站就在 La Caserne 接駁區巴士停靠點（走路 5 分鐘）。  
- 若遇潮水時間接近中午，可提早 10 分鐘出發，以免受潮汐影響接駁時間。  
- Rennes 車站內設有寄物櫃與餐廳，轉乘 TGV 很方便。  

---